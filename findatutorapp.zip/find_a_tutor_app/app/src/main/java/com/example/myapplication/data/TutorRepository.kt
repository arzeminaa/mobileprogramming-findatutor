package com.example.myapplication.data

import Data.Tutor
import kotlinx.coroutines.flow.Flow

class TutorRepository(private val tutorDao: TutorDao) {
    fun getAllTutors(): Flow<List<Tutor>> {
        return tutorDao.getAllTutors()
    }

    fun getTutorsBySubject(subject: String): Flow<List<Tutor>> {
        return tutorDao.getTutorsBySubject(subject)
    }

    fun insertTutor(tutor: Tutor) {
        tutorDao.insertTutor(tutor)
    }

    fun insertTutors(tutors: List<Tutor>) {
        tutorDao.insertTutors(tutors)
    }

    fun deleteAllTutors() {
        tutorDao.deleteAllTutors()
    }
}