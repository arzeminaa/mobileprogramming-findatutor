package com.example.myapplication;
import android.app.Application;
import androidx.room.Room
import com.example.myapplication.data.AppDatabase;
import com.example.myapplication.data.TutorRepository;

class FindATutorApp: Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
}