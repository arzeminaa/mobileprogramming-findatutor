package com.example.myapplication.data

import Data.Tutor
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TutorDao {
    @Query("SELECT * FROM tutors")
    fun getAllTutors(): Flow<List<Tutor>>

    @Query("SELECT * FROM tutors WHERE subject = :subject")
    fun getTutorsBySubject(subject: String): Flow<List<Tutor>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertTutor(tutor: Tutor)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertTutors(tutors: List<Tutor>)

    @Query("DELETE FROM tutors")
    fun deleteAllTutors()
}
