package com.example.findatutor

import Data.Tutor
import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.data.AppDatabase
import com.example.myapplication.data.TutorRepository
import androidx.navigation.NavController
import com.example.myapplication.R
import kotlinx.coroutines.launch

private lateinit var tutorRepository: TutorRepository

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val appDatabase = AppDatabase.getDatabase(this)
        tutorRepository = TutorRepository(appDatabase.tutorDao())

        setContent {
            FindATutorApp(tutorRepository)
        }
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TutorDetailPage(tutor: String, navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Tutors Details") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Tutor: $tutor",
                    style = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Text(text = "Subject: Math")
                Text(text = "Experience: 5 years")
                // Add any other details you want to display
            }
        }
    )
}

@Composable
fun FindATutorApp(tutorRepository: TutorRepository) {
    val navController = rememberNavController()
    NavHost(navController, startDestination = "landing") {
        composable("landing") {
            LandingPage(navController, tutorRepository)
        }
        composable("tutors/{subject}") { backStackEntry ->
            val subject = backStackEntry.arguments?.getString("subject")
            subject?.let {
                TutorsPage(navController, it, tutorRepository) }
        }
        composable("tutorDetail/{tutor}") { backStackEntry ->
            val tutor = backStackEntry.arguments?.getString("tutor")
            tutor?.let { tutorValue ->
                TutorDetailPage(tutorValue, navController)
            }

        }
    }
}


@Composable
fun LandingPage(navController: NavController, tutorRepository: TutorRepository) {
    val image = painterResource(R.drawable.deus_mathematics)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.LightGray)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 50.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(painter = image, contentDescription = null, contentScale = ContentScale.Fit)
            Text(
                text = "Find a Tutor ",
                style = TextStyle(
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.25.sp
                ),
                modifier = Modifier.padding(bottom = 16.dp)
            )
            SubjectOption("Math", navController)
            SubjectOption("Science", navController)
            SubjectOption("English", navController)
        }
    }
}

@Composable
fun SubjectOption(subject: String, navController: NavController) {
    Button(
        onClick = { navController.navigate("tutors/$subject") },
        modifier = Modifier
            .padding(start = 8.dp, top = 8.dp, bottom = 8.dp)
            .height(72.dp)
            .fillMaxWidth()
    ) {
        Text(
            text = subject,
            fontSize = 20.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun TutorsPage(navController: NavController, subject: String, tutorRepository: TutorRepository) {
    val tutors by tutorRepository.getAllTutors().collectAsState(emptyList())

    val filteredTutors = tutors.filter { it.subject == subject }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "Tutors") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        content = {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Tutors for $subject",
                    style = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                if (filteredTutors.isNotEmpty()) {
                    filteredTutors.forEach { tutor ->
                        TutorItem(tutor = tutor, navController = navController)
                    }
                } else {
                    Text(text = "No tutors found at this moment")
                }
            }
        }
    )
}


@Composable
fun TutorItem(tutor: Tutor, navController: NavController) {
    Text(text = tutor.name)

    IconButton(
        onClick = {
            navController.navigate("tutorDetail/${tutor.name}")
        }
    ) {
        Icon(Icons.Default.ArrowForward, contentDescription = "View Tutor Details")
    }
}

@Preview(showBackground = true)
@Composable
fun LandingPagePreview() {
    FindATutorApp(tutorRepository)
}