package com.example.myapplication.ui

import Data.Tutor
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.myapplication.FindATutorApp
import kotlinx.coroutines.flow.Flow
import com.example.myapplication.data.TutorRepository


class TutorsViewModel(private val tutorRepository: TutorRepository): ViewModel() {

    fun getAllTutors(): Flow<List<Tutor>> = tutorRepository.getAllTutors()

    suspend fun insertTutor(tutor: Tutor) {
        tutorRepository.insertTutor(tutor)
    }

    suspend fun insertTutors(tutors: List<Tutor>) {
        tutorRepository.insertTutors(tutors)
    }

    suspend fun deleteTutor() {
        tutorRepository.deleteAllTutors()
    }

    companion object {
        val factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = (this[APPLICATION_KEY] as FindATutorApp)
                val tutorDao = application.database.tutorDao()
                val tutorRepository = TutorRepository(tutorDao)
                TutorsViewModel(tutorRepository)
            }
        }
    }
}