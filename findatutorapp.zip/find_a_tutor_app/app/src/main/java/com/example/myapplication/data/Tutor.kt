package Data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import org.jetbrains.annotations.NotNull
import javax.security.auth.Subject

@Entity (tableName = "tutors")
data class Tutor (
        @PrimaryKey val id: Int,
        @NotNull
        @ColumnInfo(name = "tutor_name") val name: String,
        @NotNull
        @ColumnInfo(name = "subject") val subject: String,
        @NotNull
        @ColumnInfo (name = "experience") val experience: String
)